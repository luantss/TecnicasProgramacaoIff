public class OrdenarPorNomeComBubbleSort implements Ordenador{
    @Override
    public void ordenar(ColecaoDeMusicas colecao) {
        ordenarPorNomeComBubbleSort(colecao);
    }

    public void ordenarPorNomeComBubbleSort(ColecaoDeMusicas colecao) {

    }
}
