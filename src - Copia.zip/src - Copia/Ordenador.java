public interface Ordenador {

    public void ordenar(ColecaoDeMusicas colecao);
}
