public interface Iterador {

    public boolean temProximo();

    public No obterProximoElemento();

    public int obterIndice();

    public void reiniciar();
}
